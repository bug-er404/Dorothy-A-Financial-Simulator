var files_dup =
[
    [ "cmake-build-debug", "dir_95e29a8b8ee7c54052c171a88bb95675.html", "dir_95e29a8b8ee7c54052c171a88bb95675" ],
    [ "data", "dir_472fafaf0f039b9e6b043966c1ef7dbf.html", "dir_472fafaf0f039b9e6b043966c1ef7dbf" ],
    [ "publications", "dir_e2e4936db275e47f15d31ab73642e65f.html", null ],
    [ "Config.cpp", "_config_8cpp.html", null ],
    [ "Config.h", "_config_8h.html", [
      [ "Config", "class_config.html", "class_config" ],
      [ "ConfigValue", "struct_config_1_1_config_value.html", "struct_config_1_1_config_value" ]
    ] ],
    [ "DataAccess.cpp", "_data_access_8cpp.html", null ],
    [ "DataAccess.h", "_data_access_8h.html", [
      [ "DataAccess", "class_data_access.html", "class_data_access" ]
    ] ],
    [ "DateTime.cpp", "_date_time_8cpp.html", null ],
    [ "DateTime.h", "_date_time_8h.html", [
      [ "DateTime", "class_date_time.html", "class_date_time" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "PrefixHeader.pch", "_prefix_header_8pch.html", null ],
    [ "Simulator.cpp", "_simulator_8cpp.html", null ],
    [ "Simulator.h", "_simulator_8h.html", [
      [ "Simulator", "class_simulator.html", "class_simulator" ]
    ] ],
    [ "TickerData.cpp", "_ticker_data_8cpp.html", null ],
    [ "TickerData.h", "_ticker_data_8h.html", "_ticker_data_8h" ],
    [ "TradingStock.cpp", "_trading_stock_8cpp.html", null ],
    [ "TradingStock.h", "_trading_stock_8h.html", [
      [ "TradingStock", "class_trading_stock.html", "class_trading_stock" ]
    ] ],
    [ "Transaction.cpp", "_transaction_8cpp.html", null ],
    [ "Transaction.h", "_transaction_8h.html", [
      [ "Transaction", "class_transaction.html", "class_transaction" ]
    ] ],
    [ "Utilities.cpp", "_utilities_8cpp.html", null ],
    [ "Utilities.h", "_utilities_8h.html", "_utilities_8h" ]
];