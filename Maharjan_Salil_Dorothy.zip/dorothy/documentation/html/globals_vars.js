var globals_vars =
[
    [ "_", "globals_vars.html", null ],
    [ "c", "globals_vars_c.html", null ],
    [ "d", "globals_vars_d.html", null ],
    [ "e", "globals_vars_e.html", null ],
    [ "f", "globals_vars_f.html", null ],
    [ "h", "globals_vars_h.html", null ],
    [ "i", "globals_vars_i.html", null ],
    [ "l", "globals_vars_l.html", null ],
    [ "o", "globals_vars_o.html", null ],
    [ "s", "globals_vars_s.html", null ],
    [ "u", "globals_vars_u.html", null ],
    [ "w", "globals_vars_w.html", null ],
    [ "x", "globals_vars_x.html", null ]
];