var searchData=
[
  ['blankdate_1279',['BlankDate',['../class_date_time.html#a13c417f101c5254d27117e5a1415d632',1,'DateTime']]]
];
