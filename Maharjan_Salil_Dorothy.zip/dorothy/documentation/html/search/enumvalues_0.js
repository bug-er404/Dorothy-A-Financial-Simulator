var searchData=
[
  ['adj_5fclose_1418',['ADJ_CLOSE',['../_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafa3c9301d3b5db85466b68c50332e09d54',1,'TickerData.h']]]
];
