var searchData=
[
  ['close_1419',['CLOSE',['../_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafa685f73194ad125cbc784c3210cdb3449',1,'TickerData.h']]]
];
