var searchData=
[
  ['na_5fval_1398',['NA_VAL',['../class_ticker_data.html#a875fa60f1877615e9ca408b697b27905',1,'TickerData']]]
];
