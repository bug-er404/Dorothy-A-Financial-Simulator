var searchData=
[
  ['newtradingday_858',['newTradingDay',['../class_trading_stock.html#a2942da99da8b25978168083c5e29be72',1,'TradingStock']]],
  ['nextdayinposition_859',['NextDayInPosition',['../class_transaction.html#afba291c3886ecf68a948a012f81ea74d',1,'Transaction']]]
];
