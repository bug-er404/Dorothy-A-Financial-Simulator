var searchData=
[
  ['tickerdata_902',['TickerData',['../class_ticker_data.html#a9d7b95aba7d6e6f002b8efd39f05f73f',1,'TickerData::TickerData(std::string &amp;a_tickerName, const std::string &amp;a_directory)'],['../class_ticker_data.html#ae29619f5b91cd6a8f348a72f244f1d36',1,'TickerData::TickerData()=default']]],
  ['tradingstock_903',['TradingStock',['../class_trading_stock.html#acf37f3142597c43e861aeba34fe7b303',1,'TradingStock::TradingStock(std::string a_tickerName, double a_startingCapital)'],['../class_trading_stock.html#a3ebff0c1f91ab2f961b9665c2865b74f',1,'TradingStock::TradingStock()=default']]],
  ['transaction_904',['Transaction',['../class_transaction.html#a9ff3e14de368615046e75ab122caa327',1,'Transaction::Transaction(DateTime *a_date, double a_signal, double a_share, double a_price)'],['../class_transaction.html#ab47005b855d38bc324bb79fd023baa13',1,'Transaction::Transaction()']]],
  ['trimblanks_905',['trimBlanks',['../class_config.html#add5f97cae5bee6215791bd9c346fffcf',1,'Config::trimBlanks()'],['../namespace_utilities.html#a0ab4e4bfac17a04ab38640746aba42fe',1,'Utilities::trimBlanks()']]]
];
