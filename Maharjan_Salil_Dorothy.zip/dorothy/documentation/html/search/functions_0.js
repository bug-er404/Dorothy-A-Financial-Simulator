var searchData=
[
  ['_5f_5fattribute_5f_5f_761',['__attribute__',['../_c_make_cache_8txt.html#a8ddf43ba1753be5c36226b049d362951',1,'__attribute__((__blocks__(byref))):&#160;CMakeCache.txt'],['../_c_make_cache_8txt.html#a1ddbf8690bcf0c35a8e98f455664beb1',1,'__attribute__((objc_gc(weak))):&#160;CMakeCache.txt']]]
];
