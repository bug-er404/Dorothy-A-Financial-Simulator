var searchData=
[
  ['open_1431',['OPEN',['../_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafa0e0143636c29971736eab47415868eae',1,'TickerData.h']]]
];
