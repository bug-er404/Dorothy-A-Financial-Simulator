var searchData=
[
  ['recorddailyreturn_878',['RecordDailyReturn',['../class_trading_stock.html#a08f0c522a18efec82f4c272e0d03fe7c',1,'TradingStock']]],
  ['recorddailystatistics_879',['recordDailyStatistics',['../class_simulator.html#ae77749f93581b683330f30726f5aaffb',1,'Simulator']]],
  ['recordmonthlystatistics_880',['recordMonthlyStatistics',['../class_simulator.html#ae9b8b2ffbef1ba49bd8a9dc5fad5a1b2',1,'Simulator']]],
  ['recordnoactivity_881',['recordNoActivity',['../class_simulator.html#a4238ab87912e40d99cad5deb558e3a96',1,'Simulator']]],
  ['recordpnl_882',['RecordPNL',['../class_trading_stock.html#a82ea8bcd2b94eef82bb100c929c519e0',1,'TradingStock']]],
  ['recordsharperatio_883',['recordSharpeRatio',['../class_simulator.html#accf533fb22ca8261dce0830daa5945f1',1,'Simulator']]],
  ['recordsignal_884',['RecordSignal',['../class_trading_stock.html#abe36e5075cacda88997a32e5f4923ee6',1,'TradingStock']]],
  ['recordsignalinfo_885',['recordSignalInfo',['../class_simulator.html#a5a78edbf904b54bb6f66a5c3b8c87cd9',1,'Simulator']]],
  ['recordtransaction_886',['recordTransaction',['../class_simulator.html#a56638656f8e85aec70ba6c2680025279',1,'Simulator']]],
  ['recordtransactionscount_887',['RecordTransactionsCount',['../class_trading_stock.html#af0ebb1d62314db9844a05255605fc47a',1,'TradingStock']]],
  ['rerunsimulator_888',['rerunSimulator',['../class_simulator.html#a0cd976fca52f982a92f2f897a6ddd1de',1,'Simulator']]],
  ['reverseoffset_889',['reverseOffset',['../class_date_time.html#aa8a746c7fb47a7034adde3fb83c79dbe',1,'DateTime']]],
  ['roundoff_890',['RoundOff',['../namespace_utilities.html#a0257a93580460c13c4af232704caa0dc',1,'Utilities']]],
  ['runsimulation_891',['RunSimulation',['../class_simulator.html#a9a703ddcca1a802b3df9a9dc921927ae',1,'Simulator']]]
];
