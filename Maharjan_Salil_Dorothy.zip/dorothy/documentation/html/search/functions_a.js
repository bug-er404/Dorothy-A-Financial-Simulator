var searchData=
[
  ['openposition_860',['OpenPosition',['../class_trading_stock.html#a4398bf190fdf2e8f089e929b60fe2e6d',1,'TradingStock']]],
  ['openpositions_861',['openPositions',['../class_simulator.html#ad24c99fbfd5808aba7f5c9de11cc23f0',1,'Simulator']]],
  ['operator_20int_862',['operator int',['../class_date_time.html#a64627ec59244ab71e4fab3b021fc1af8',1,'DateTime']]],
  ['operator_21_3d_863',['operator!=',['../class_date_time.html#a3e816351592ec442e04774d108a86612',1,'DateTime::operator!=(const DateTime &amp;a_date)'],['../class_date_time.html#abf91e4e2aa566964dc91b84985645f89',1,'DateTime::operator!=(int a_date)']]],
  ['operator_2b_864',['operator+',['../class_date_time.html#a698ebe694145c3be698ff0a0588b15da',1,'DateTime']]],
  ['operator_2b_2b_865',['operator++',['../class_date_time.html#a38c7ae7996e0966e67e13d79866ba409',1,'DateTime::operator++()'],['../class_date_time.html#a0fe9a32549329c66d6cf58d14ab705df',1,'DateTime::operator++(int)']]],
  ['operator_2d_866',['operator-',['../class_date_time.html#a7914e7a4ef2ad2a5729b90c2c07bea3c',1,'DateTime::operator-(const DateTime &amp;a_date)'],['../class_date_time.html#a2e5295058ae6b112e9bf5b0226456005',1,'DateTime::operator-(int a_days)']]],
  ['operator_2d_2d_867',['operator--',['../class_date_time.html#afc219149a3d959863c84e3a15530dc54',1,'DateTime::operator--()'],['../class_date_time.html#aca232974e8aa4a1608c50f5714a9b961',1,'DateTime::operator--(int)']]],
  ['operator_3c_868',['operator&lt;',['../class_date_time.html#a8af0104c406f0c3a13f5e3299af6c203',1,'DateTime::operator&lt;(const DateTime &amp;a_date)'],['../class_date_time.html#a2241f0caf5a91c94a29c265bfd22baf3',1,'DateTime::operator&lt;(int a_date)']]],
  ['operator_3c_3d_869',['operator&lt;=',['../class_date_time.html#a6b9df88cc66e7e7547931dccf1e1ea51',1,'DateTime::operator&lt;=(const DateTime &amp;a_date)'],['../class_date_time.html#aa208d749051b44abb6e85acf024f0302',1,'DateTime::operator&lt;=(int a_date)']]],
  ['operator_3d_870',['operator=',['../class_data_access.html#aec4ac0b293f6123602cb5edd1dd58652',1,'DataAccess::operator=()'],['../class_date_time.html#a64da6b1771656edb1e0d44eb3e88deb2',1,'DateTime::operator=(const DateTime &amp;a_date)'],['../class_date_time.html#a75243ae5f1f368ba0d72a9882a934d25',1,'DateTime::operator=(int a_date)']]],
  ['operator_3d_3d_871',['operator==',['../class_date_time.html#ae2f878dfd2243aee2ca2000f58f8fe9a',1,'DateTime::operator==(const DateTime &amp;a_date)'],['../class_date_time.html#a3758612658764a9bf153ea8007dde4ad',1,'DateTime::operator==(int a_date)']]],
  ['operator_3e_872',['operator&gt;',['../class_date_time.html#a2180c1804eecdf469107b7629cabba3d',1,'DateTime::operator&gt;(const DateTime &amp;a_date)'],['../class_date_time.html#a3ae99354564bfa6c35a34b10b1edd817',1,'DateTime::operator&gt;(int a_date)']]],
  ['operator_3e_3d_873',['operator&gt;=',['../class_date_time.html#a39d825cab864948325623eecf09ef722',1,'DateTime::operator&gt;=(const DateTime &amp;a_date)'],['../class_date_time.html#a8293f2faa8e62864b80a42f2ff0ae3e6',1,'DateTime::operator&gt;=(int a_date)']]]
];
