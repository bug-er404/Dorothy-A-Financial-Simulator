var _utilities_8h =
[
    [ "GetAverage", "_utilities_8h.html#a80b350cec72abbcf34ad7e28405d531c", null ],
    [ "GetStandardDeviation", "_utilities_8h.html#a175ab95f5c509ccc3d4b571e8963f22e", null ],
    [ "RoundOff", "_utilities_8h.html#a0257a93580460c13c4af232704caa0dc", null ],
    [ "trimBlanks", "_utilities_8h.html#a0ab4e4bfac17a04ab38640746aba42fe", null ]
];