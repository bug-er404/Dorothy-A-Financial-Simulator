var _ticker_data_8h =
[
    [ "TickerData", "class_ticker_data.html", "class_ticker_data" ],
    [ "TICKER_FIELDS", "_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafaf", [
      [ "OPEN", "_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafa0e0143636c29971736eab47415868eae", null ],
      [ "START_TICKER_FIELDS", "_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafa3ad35f437b4427db031733f716648b1b", null ],
      [ "DATA_FIELD_START", "_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafa208d7742c684795f35b2d90499d04356", null ],
      [ "HIGH", "_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafa0c3a1dacf94061154b3ee354359c5893", null ],
      [ "LOW", "_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafa6a226f4143ca3b18999551694cdb72a8", null ],
      [ "CLOSE", "_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafa685f73194ad125cbc784c3210cdb3449", null ],
      [ "VOLUME", "_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafa9d326c2efb1f1ef1840d474c0f9b8a48", null ],
      [ "ADJ_CLOSE", "_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafa3c9301d3b5db85466b68c50332e09d54", null ],
      [ "DIVIDEND", "_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafa5bb1d61946cf3b388960a86623fdb5e4", null ],
      [ "SPLIT", "_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafa7cf1f5924560c2c48f72f6e1a462e9c9", null ],
      [ "VWAP", "_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafa689cbd84f20f3ce37e7348cef1ff0a49", null ],
      [ "SHARE_OUTSTANDING", "_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafa822c3fb0a7fbc8057c21c3b16e5a9a72", null ],
      [ "DATA_FIELD_END", "_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafa8725d89a00e29ee0935be179f89db864", null ],
      [ "FAST_EMA", "_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafa08596ee828503af3aa2e2278a3e414da", null ],
      [ "SLOW_EMA", "_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafa97f12d998aa17b72732bd697aa16d8f8", null ],
      [ "MACD_LINE", "_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafa02d7b0434a6c73c9dae1d16ff649b980", null ],
      [ "SIG_LINE", "_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafaa5290299e5bf77e1609551751ef1ea58", null ],
      [ "MACD_HIST", "_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafa6f1880bb6a3f566a19cbbbfddfb204b8", null ],
      [ "END_TICKER_FIELDS", "_ticker_data_8h.html#a698cb0bfc890ce6b194caf0f426cafafa884806b8188679868516f4e19428dd13", null ]
    ] ]
];